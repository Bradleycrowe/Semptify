from .legal_resource_scanner import scan_legal_resources, register_module
__all__ = ["scan_legal_resources", "register_module"]
