## Know Your Rights Qt5Py GUI
Modal interface for tenants to select real-life scenarios and receive instant legal guidance.
Includes:
- Scenario dropdown
- Rights summary generator
- Escalation button
- Legal graphic placeholder
- Multilingual-ready layout
