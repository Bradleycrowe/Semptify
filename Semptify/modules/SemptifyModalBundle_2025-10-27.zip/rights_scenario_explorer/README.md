Rights Scenario Explorer: guides tenants through real-life legal situations with instant complaint tools.
