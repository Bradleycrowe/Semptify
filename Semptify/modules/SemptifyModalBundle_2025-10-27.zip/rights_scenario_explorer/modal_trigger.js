// Trigger modal for scenario selection
