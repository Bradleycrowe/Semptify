# Aggregates violations and visualizes patterns
