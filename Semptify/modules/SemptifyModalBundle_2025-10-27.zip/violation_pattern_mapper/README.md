Violation Pattern Mapper: logs tenant violations and visualizes abuse patterns across landlords and buildings.
