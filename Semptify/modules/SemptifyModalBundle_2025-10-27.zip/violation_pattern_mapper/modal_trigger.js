// Trigger modal for violation logging
